from ultralytics import YOLO

model = YOLO("yolov8n.yaml")  # build nano model for laptops

results = model.train(data="detect-camo8.yaml", epochs=4)
